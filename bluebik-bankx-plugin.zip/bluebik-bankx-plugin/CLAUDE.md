# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this repo is

A **Claude Code plugin** that ships three custom subagents for the Siam Commercial Bank (BankX) backend team. There is no application code, no build, no tests — the repo is pure configuration: Markdown agent definitions plus plugin/marketplace manifests. "Editing the codebase" here means editing prompts.

## Layout

- `.claude-plugin/plugin.json` — plugin manifest consumed by Claude Code. `name: bluebik-bankx`, current `version: 1.0.0`. Bump this when shipping changes.
- `.claude-plugin/marketplace.json` — local marketplace descriptor pointing back at `./`. Used for `/plugin marketplace add` style installs.
- `agents/*.md` — one file per subagent. The YAML frontmatter is the agent's contract with Claude Code; the Markdown body is the system prompt the agent runs with.

## The five agents (what they are, why each exists)

All agents are `model: opus` and reference external rule/source/doc directories by **absolute path on the plugin author's machine**. Keep this in mind: the prompts are written assuming those paths resolve — they are not portable across machines without edits.

- **`bankx-code-reviewer`** — read-only reviewer (`tools: Read, Grep, Glob, Bash`). Hard contract: produces a structured BLOCKER/MAJOR/MINOR/INFO findings report in a machine-consumable format so a downstream *developer* agent can apply the fixes. It must cite rule file + section for every finding and must not invent rules. If you edit this prompt, preserve the exact output schema (Summary + numbered Findings with `severity/file/rule/problem/required_change/suggested_patch`) — downstream automation depends on it.
- **`bankx-framework-expert`** — deep expert on the in-house `bank-x-spring-framework` multi-module Maven project (starter parent, common, server aggregator, and the web/redis/jdbc/mybatis/id/log/batch/state-machine/generator/test starters). Has `Edit, Write` so it can modify framework source. Also treats the full corpus of BankX services cloned under `/Users/Sittidej.t.extbankx.live/Projects/BankX/Platform/` (core domain services like `customer`/`deposit`/`notification`/`ekyc`, inbound adapters, outbound adapters, batch services, `SampleProj`) as a real-world pattern library — the agent greps across them to ground "how do we actually do X" recommendations. Operating rules baked into the prompt: **read framework source before answering runtime questions**, **cross-reference the service corpus before prescribing an idiom**, and never claim "pattern" for a single-service example — two+ services must agree.
- **`java-backend-architect`** — senior implementer + architect bound to the BankX engineering rules. Has `Edit, Write`. Writes production Java/Spring Boot code that must satisfy the BankX rules on first pass (GeneralResponse envelope, constructor DI, MapStruct, virtual threads, no PII in logs, layered package structure, `StandardBaseException`, etc.).
- **`bankx-api-doc-writer`** — API spec author. Has `Edit, Write`. Produces Markdown feature docs in the BankX house style (anchored on `document/platform/features/notification/` as the canonical examples), Mermaid `sequenceDiagram`/`erDiagram` blocks, and OpenAPI 3.1 specs. Writes docs only — does not implement services. Operating rule baked into the prompt: **read at least one canonical notification doc before writing**, to anchor on the numbering, diagram idioms, and response-envelope patterns already established.
- **`bankx-database-architect`** — PostgreSQL + Redis specialist (with Mongo/Cassandra/ES awareness). Has `Bash, Edit, Write` so it can run `psql`/`redis-cli` for introspection and author migration DDL + design notes. Hard operating rule baked into the prompt: **read-only against live databases** — no `DROP`/`DELETE`/`TRUNCATE`/`ALTER`/`FLUSHDB`, no `KEYS *`, no DDL/DML execution. It proposes DDL files for the user or pipeline to apply. Always confirms connection details before touching anything beyond local dev.

## External sources the agents depend on

These paths live **outside** this repo and the agent prompts hard-code them. If either moves, every agent breaks.

- `/Users/Sittidej.t.extbankx.live/Projects/BankX/Foundation/document/ai-rules/` — the BankX engineering rule set (`master_rule.md`, `backend/java/*.md`, `api_design/README.md`, `database/README.md`). `bankx-code-reviewer`, `java-backend-architect`, `bankx-api-doc-writer`, and `bankx-database-architect` cite this directly.
- `/Users/Sittidej.t.extbankx.live/Projects/BankX/Foundation/bank-x-spring-framework/` — the framework source `bankx-framework-expert` reads from.
- `/Users/Sittidej.t.extbankx.live/Projects/BankX/Platform/` (sibling service repos) — the BankX service corpus `bankx-framework-expert` explores for real-world usage patterns. Service categories: core domain (`customer`, `customer-auth`, `customer-consent-document`, `deposit`, `deposit-batch`, `ekyc`, `notification`, `terms-conditions-service`), inbound adapters (`true-sms-provider-inbound-adapter`, `ais-sms-provider-inbound-adapter`, `ndid-inbound-adapter`), outbound adapters (`ekyc-adapter`, `corebank-adapter`, `dopa-outbound-adapter`, `braze-outbound-adapter`, `ndid-outbound-adapter`, `name-screening-outbound-adapter`, `seven-eleven-adapter`), and the `SampleProj` scaffold. On this machine only `ekyc` is currently cloned; the agent will find any others by glob if you clone them under `Platform/`.
- `/Users/Sittidej.t.extbankx.live/Projects/BankX/Foundation/document/platform/features/notification/` — canonical API-doc examples (`email-verification.md`, `inbox.md`, `push-notification.md`, `send-email.md`, `sms-gateway.md`, `true-sms-provider-inbound-adapter.md`, `users-track.md`) that `bankx-api-doc-writer` uses as its primary style anchor for feature-API docs. If this folder moves or its conventions diverge, the writer's output will drift.
- `/Users/Sittidej.t.extbankx.live/Projects/BankX/Foundation/document/platform/features/NDID/` — secondary style anchor used by `bankx-api-doc-writer` specifically when producing inbound/outbound adapter specs (`NDID.md` for conceptual background, `NDID_spec.md` as the adapter spec skeleton).

When adapting this plugin for another environment, those paths must be updated consistently across all five agent files.

## Installing / testing locally

From `README.md`:

```bash
claude --plugin-dir /path/to/bluebik-bankx-plugin
```

Or, per project, in `.claude/settings.json`:

```json
{ "plugins": [{ "type": "local", "path": "/path/to/bluebik-bankx-plugin" }] }
```

Namespaced invocation once installed: `/bluebik-bankx:bankx-framework-expert`, `/bluebik-bankx:java-backend-architect`, `/bluebik-bankx:bankx-code-reviewer`. Programmatic invocation: `Agent` tool with `subagent_type` set to the agent name.

## Editing conventions for this repo

- **Agent frontmatter is load-bearing.** `name`, `description`, `tools`, `model` drive when Claude Code auto-selects the agent and what it can do. Touching `description` changes proactive-invocation behavior; touching `tools` changes capability. Do not add `Edit`/`Write` to `bankx-code-reviewer` — its whole point is that it does not modify code.
- **Plugin + marketplace manifests must stay consistent.** `plugin.json.name` (`bluebik-bankx`) is what's referenced in `marketplace.json` and in install commands. Rename in one place → rename everywhere.
- **Version bumps.** When you ship a prompt change users should pick up, bump `.claude-plugin/plugin.json` `version`. There is no separate changelog file — use the commit message.
- **Prompt changes are behavior changes.** There are no tests here; the only way to validate an edit is to install the plugin locally and exercise the agent. Prefer small, reversible edits.
