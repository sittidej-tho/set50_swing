# Bluebik BankX Plugin

Custom Claude Code agents for the BankX platform team.

## Agents

- **bankx-framework-expert** -- Deep expertise on the bank-x-spring-framework (starters, parent POM, common module). Use for framework debugging, starter selection, Maven inheritance issues, and designing new microservices on top of BankX primitives.

- **java-backend-architect** -- Senior Java/Spring Boot architect and implementer. Use for designing services and APIs, implementing production-grade controllers/services/repositories/DTOs, security hardening, writing tests, and reviewing architecture. Bound to BankX engineering rules.

- **bankx-code-reviewer** -- Automated code reviewer enforcing BankX engineering rules. Use after non-trivial code changes, before commits/PRs, or for convention compliance checks. Produces structured, actionable violation reports.

- **bankx-api-doc-writer** -- API specification author. Writes feature docs in the BankX Markdown house style (matching `document/platform/features/notification/`), Mermaid sequence/ER diagrams, and OpenAPI 3.1 specs. Use when creating or updating feature docs under `document/platform/features/`.

- **bankx-database-architect** -- Database specialist for PostgreSQL and Redis (with Mongo/Cassandra/ES awareness). Designs schemas for new features, introspects live databases to map current tables/relationships, proposes migration DDL conforming to BankX conventions, and advises on indexing/partitioning/concurrency. Read-only against live databases — proposes DDL, does not execute it.

## Installation

### Local testing

```bash
claude --plugin-dir /path/to/bluebik-bankx-plugin
```

### Per-project

Add to your project's `.claude/settings.json`:

```json
{
  "plugins": [
    {
      "type": "local",
      "path": "/path/to/bluebik-bankx-plugin"
    }
  ]
}
```

### Via GitHub marketplace (team-wide)

```bash
/plugin marketplace add your-org/bluebik-bankx-plugin
/plugin install bluebik-bankx@your-org-repo
```

## Usage

Once installed, agents are available via namespaced commands:

```
/bluebik-bankx:bankx-framework-expert
/bluebik-bankx:java-backend-architect
/bluebik-bankx:bankx-code-reviewer
/bluebik-bankx:bankx-api-doc-writer
/bluebik-bankx:bankx-database-architect
```

Or invoke programmatically via the Agent tool with `subagent_type`.